const backendUrl = 'http://localhost:3005';

export default backendUrl;
